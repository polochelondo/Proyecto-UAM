console.log("Hello world")
var a=1;
var b=2;
var R=a+b;
console.log("Resultado: " + R);

var n=1;
var m=2;
var R=n*m;
console.log("Resultado: " + R);

var raiz=Math.sqrt(1244);
console.log("La raiz cuadrada de 1244 es: "+raiz);

var raiz2=Math.trunc(raiz);
console.log("Esto, aproximado al numero entero mas cercano, es igual a: "+raiz2);

var c = 100;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log(numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}

   











